package com.igt.keyemployee.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.igt.keyemployee.domain.Account;
import com.igt.keyemployee.domain.KeyEmployee;
import com.igt.keyemployee.service.KeyEmployeeService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/checkKeyEmployee")
@Slf4j
public class KeyEmployewController {

  private final KeyEmployeeService keyEmployeeService;

  @Autowired
  public KeyEmployewController(KeyEmployeeService keyEmployeeService) {
    this.keyEmployeeService = keyEmployeeService;
  }

 

  @PostMapping
  public KeyEmployee checkKeyEmployee(@RequestBody KeyEmployee keyEmployee) {
   // log.info("Retrieving account for id {}", accountId);
	  
    return this.keyEmployeeService.checkKeyEmployee(keyEmployee);
  }

}
