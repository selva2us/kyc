package com.igt.keyemployee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igt.keyemployee.domain.KeyEmployee;
import com.igt.keyemployee.repository.KeyEmployeeRepository;

import lombok.Getter;

@Service
public class KeyEmployeeService {

  @Getter
  private final KeyEmployeeRepository keyEmployeeRepository;

  @Autowired
  public KeyEmployeeService(KeyEmployeeRepository keyEmployeeRepository) {
    this.keyEmployeeRepository = keyEmployeeRepository;
  }

  public KeyEmployee checkKeyEmployee(KeyEmployee accountId) {
	
   return this.keyEmployeeRepository.checkKeyEmployee(accountId);
  }
}
