package com.igt.keyemployee.repository;

import com.igt.keyemployee.domain.Account;
import com.igt.keyemployee.domain.KeyEmployee;
import com.igt.keyemployee.exception.DuplicateAccountIdException;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Repository;

@Repository
public class KeyEmployeeRepositoryInMemory implements KeyEmployeeRepository {

  private final Map<String, Account> accounts = new ConcurrentHashMap<>();

@Override
public KeyEmployee checkKeyEmployee(KeyEmployee keyEmployee) {
	// TODO Auto-generated method stub
	return keyEmployee;
}

 /* @Override
  public void createAccount(Account account) throws DuplicateAccountIdException {
    Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
    if (previousAccount != null) {
      throw new DuplicateAccountIdException(
        "Account id " + account.getAccountId() + " already exists!");
    }
  }

  @Override
  public Account getAccount(String accountId) {
	  Account account=new Account("12345");
	  accounts.put("12345", account);
    return accounts.get(accountId);
  }

  @Override
  public void clearAccounts() {
    accounts.clear();
  }
*/
}
