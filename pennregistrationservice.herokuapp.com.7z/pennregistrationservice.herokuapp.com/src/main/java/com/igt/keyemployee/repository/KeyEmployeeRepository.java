package com.igt.keyemployee.repository;

import com.igt.keyemployee.domain.KeyEmployee;

public interface KeyEmployeeRepository {

	KeyEmployee checkKeyEmployee(KeyEmployee account) ;

 
}
